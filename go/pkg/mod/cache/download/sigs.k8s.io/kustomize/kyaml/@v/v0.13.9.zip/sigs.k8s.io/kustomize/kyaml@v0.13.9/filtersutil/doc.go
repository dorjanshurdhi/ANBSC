// Copyright 2019 The Kubernetes Authors.
// SPDX-License-Identifier: Apache-2.0

// Package filtersutil provides utilities for working with yaml.Filter and
// kio.Filter interfaces.
package filtersutil
