// Copyright 2022 The Kubernetes Authors.
// SPDX-License-Identifier: Apache-2.0

// Package gkesagenerator contains a kio.Filter that that generates a
// iampolicy-related resources for a given cloud provider
package iampolicygenerator
