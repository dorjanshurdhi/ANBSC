// Copyright 2021 The Kubernetes Authors.
// SPDX-License-Identifier: Apache-2.0

// Package suffix contains a kio.Filter implementation of the kustomize
// SuffixTransformer.
package suffix
