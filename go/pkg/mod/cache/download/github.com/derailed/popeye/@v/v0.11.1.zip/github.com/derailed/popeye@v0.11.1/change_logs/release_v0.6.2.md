<img src="https://raw.githubusercontent.com/derailed/popeye/master/assets/popeye.png" align="right" width="200" height="auto"/>

# Release v0.6.2

## Notes

Thank you so much for your support and suggestions to make Popeye better!!

If you dig this tool, please make some noise on social! [@kitesurfer](https://twitter.com/kitesurfer)

---

## Change Logs

Maintenance release!

# GitHub Sponsorships

As you may have noticed this project now offers a GitHub Sponsor button (over there 👆).
If you feel `Popeye` sanitizers are helping you diagnose potential cluster issues and his saving you some cycles, you may consider sponsorizing this project. Thank you for your gesture of kindness and for supporting Popeye!! (not to mention helping replainish my liquids during oh-dark-thirty hours 🍺🍹🍸)

---

## Resolved Bugs

* [Issue #77](https://github.com/derailed/popeye/issues/77)

---

<img src="https://raw.githubusercontent.com/derailed/popeye/master/assets/imhotep_logo.png" width="32" height="auto"/>&nbsp; © 2019 Imhotep Software LLC. All materials licensed under [Apache v2.0](http://www.apache.org/licenses/LICENSE-2.0)
