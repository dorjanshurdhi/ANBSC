// Package mutil contains various functions that are helpful when writing http
// middleware.
//
// It has been vendored from Goji v1.0, with the exception of the code for Go 1.8:
// https://github.com/zenazn/goji/
package mutil
